package com.cricketmanager.app.sync

import android.content.Context
import com.cricketmanager.app.data.local.TournamentEntity
import com.cricketmanager.app.domain.BackupSerializer
import com.cricketmanager.app.domain.TournamentBackupBundle
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class CloudSyncResult {
    data class Synced(val syncedCount: Int) : CloudSyncResult()
    data object NotConfigured : CloudSyncResult()
    data class Error(val message: String) : CloudSyncResult()
}

class FirebaseSyncBridge(private val context: Context) {

    fun isFirebaseConfigured(): Boolean {
        return runCatching { FirebaseApp.getApps(context).isNotEmpty() }.getOrDefault(false)
    }

    fun currentUid(): String? {
        if (!isFirebaseConfigured()) return null
        return runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull()
    }

    suspend fun signInOrRegisterFirebase(email: String, password: String): Result<String> {
        if (!isFirebaseConfigured()) {
            return Result.failure(IllegalStateException("google-services.json not configured"))
        }
        return runCatching {
            val auth = FirebaseAuth.getInstance()
            val result = try {
                awaitTask(auth.signInWithEmailAndPassword(email, password))
            } catch (_: Exception) {
                awaitTask(auth.createUserWithEmailAndPassword(email, password))
            }
            result.user?.uid ?: "anonymous"
        }
    }

    suspend fun pushTournamentBundle(
        bundle: TournamentBackupBundle,
        ownerUid: String,
        editorUids: List<String> = emptyList()
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        return try {
            val firestore = FirebaseFirestore.getInstance()
            val t = bundle.tournament
            val docRef = firestore.collection("tournaments").document(t.tournamentCode)
            val bundleJson = BackupSerializer.exportTournamentJson(bundle)
            val payload = mapOf(
                "localId" to t.id,
                "name" to t.name,
                "logoEmoji" to t.logoEmoji,
                "pitchType" to t.pitchType.name,
                "scoringMode" to t.scoringMode.name,
                "format" to t.format.name,
                "oversPerMatch" to t.oversPerMatch,
                "tournamentCode" to t.tournamentCode,
                "editorCode" to t.editorCode,
                "viewerCode" to t.viewerCode,
                "ownerUid" to ownerUid,
                "editorUids" to editorUids.distinct(),
                "updatedAt" to t.updatedAt,
                "bundleJson" to bundleJson
            )
            awaitTask(docRef.set(payload, SetOptions.merge()))

            bundle.teams.forEach { team ->
                val teamMap = mapOf(
                    "id" to team.id,
                    "name" to team.name,
                    "shortCode" to team.shortCode,
                    "played" to team.played,
                    "won" to team.won,
                    "points" to team.points,
                    "updatedAt" to t.updatedAt
                )
                awaitTask(docRef.collection("teams").document(team.id.toString()).set(teamMap, SetOptions.merge()))
            }

            bundle.players.forEach { player ->
                val playerMap = mapOf(
                    "id" to player.id,
                    "teamId" to player.teamId,
                    "name" to player.name,
                    "runsScored" to player.runsScored,
                    "wicketsTaken" to player.wicketsTaken,
                    "updatedAt" to t.updatedAt
                )
                awaitTask(docRef.collection("players").document(player.id.toString()).set(playerMap, SetOptions.merge()))
            }

            bundle.matches.forEach { m ->
                val matchMap = mapOf(
                    "id" to m.id,
                    "matchNumber" to m.matchNumber,
                    "stage" to m.stage.name,
                    "teamAId" to m.teamAId,
                    "teamBId" to m.teamBId,
                    "teamARuns" to m.teamARuns,
                    "teamAWickets" to m.teamAWickets,
                    "teamABalls" to m.teamABalls,
                    "teamBRuns" to m.teamBRuns,
                    "teamBWickets" to m.teamBWickets,
                    "teamBBalls" to m.teamBBalls,
                    "status" to m.status.name,
                    "winnerTeamId" to m.winnerTeamId,
                    "resultSummary" to m.resultSummary,
                    "updatedAt" to m.updatedAt
                )
                awaitTask(docRef.collection("matches").document(m.matchNumber.toString()).set(matchMap, SetOptions.merge()))
            }

            bundle.members.forEach { mem ->
                val memMap = mapOf(
                    "userId" to mem.userId,
                    "userName" to mem.userName,
                    "userEmail" to mem.userEmail,
                    "role" to mem.role.name,
                    "canScore" to mem.canScore
                )
                awaitTask(docRef.collection("members").document(mem.userId.toString()).set(memMap, SetOptions.merge()))
            }

            bundle.balls.forEachIndexed { idx, ball ->
                val ballMap = mapOf(
                    "matchId" to ball.matchId,
                    "innings" to ball.innings,
                    "sequenceNumber" to ball.sequenceNumber,
                    "summaryLabel" to ball.summaryLabel,
                    "timestamp" to ball.timestamp
                )
                awaitTask(docRef.collection("balls").document("${ball.matchId}_${ball.innings}_${ball.sequenceNumber}_$idx").set(ballMap, SetOptions.merge()))
            }

            bundle.logs.take(50).forEachIndexed { idx, log ->
                val logMap = mapOf(
                    "actorName" to log.actorName,
                    "actionTitle" to log.actionTitle,
                    "details" to log.details,
                    "createdAt" to log.createdAt
                )
                awaitTask(docRef.collection("auditLogs").document("${log.createdAt}_$idx").set(logMap, SetOptions.merge()))
            }

            CloudSyncResult.Synced(1)
        } catch (e: Exception) {
            CloudSyncResult.Error(e.message ?: "Cloud sync error")
        }
    }

    suspend fun pushDirtyBundles(
        bundles: List<TournamentBackupBundle>,
        ownerUid: String
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        var syncedCount = 0
        for (bundle in bundles) {
            when (val res = pushTournamentBundle(bundle, ownerUid)) {
                is CloudSyncResult.Synced -> syncedCount += res.syncedCount
                is CloudSyncResult.Error -> return res
                CloudSyncResult.NotConfigured -> return CloudSyncResult.NotConfigured
            }
        }
        return CloudSyncResult.Synced(syncedCount)
    }

    suspend fun pushDirtyTournaments(
        tournaments: List<TournamentEntity>,
        ownerUid: String
    ): CloudSyncResult {
        if (!isFirebaseConfigured()) {
            return CloudSyncResult.NotConfigured
        }
        return try {
            val firestore = FirebaseFirestore.getInstance()
            var count = 0
            for (t in tournaments) {
                val payload = mapOf(
                    "localId" to t.id,
                    "name" to t.name,
                    "logoEmoji" to t.logoEmoji,
                    "pitchType" to t.pitchType.name,
                    "scoringMode" to t.scoringMode.name,
                    "format" to t.format.name,
                    "oversPerMatch" to t.oversPerMatch,
                    "tournamentCode" to t.tournamentCode,
                    "editorCode" to t.editorCode,
                    "viewerCode" to t.viewerCode,
                    "ownerUid" to ownerUid,
                    "updatedAt" to t.updatedAt
                )
                awaitTask(
                    firestore.collection("tournaments")
                        .document(t.tournamentCode)
                        .set(payload, SetOptions.merge())
                )
                count++
            }
            CloudSyncResult.Synced(count)
        } catch (e: Exception) {
            CloudSyncResult.Error(e.message ?: "Cloud sync error")
        }
    }

    suspend fun pullTournamentByCode(code: String, currentUserId: Long): Result<TournamentBackupBundle?> {
        if (!isFirebaseConfigured()) {
            return Result.success(null)
        }
        val clean = code.trim().uppercase()
        return runCatching {
            val firestore = FirebaseFirestore.getInstance()
            val tournamentsRef = firestore.collection("tournaments")
            var doc: DocumentSnapshot? = null

            val direct = awaitTask(tournamentsRef.document(clean).get())
            if (direct.exists()) {
                doc = direct
            }
            if (doc == null) {
                val byEditor = awaitTask(tournamentsRef.whereEqualTo("editorCode", clean).limit(1).get())
                doc = byEditor.documents.firstOrNull()
            }
            if (doc == null) {
                val byViewer = awaitTask(tournamentsRef.whereEqualTo("viewerCode", clean).limit(1).get())
                doc = byViewer.documents.firstOrNull()
            }
            val found = doc ?: return@runCatching null
            val bundleJson = found.getString("bundleJson") ?: return@runCatching null
            val parsed = BackupSerializer.parseTournamentJson(bundleJson, currentUserId)
            val cloudTournament = parsed.tournament.copy(
                tournamentCode = found.getString("tournamentCode") ?: parsed.tournament.tournamentCode,
                editorCode = found.getString("editorCode") ?: parsed.tournament.editorCode,
                viewerCode = found.getString("viewerCode") ?: parsed.tournament.viewerCode,
                updatedAt = found.getLong("updatedAt") ?: parsed.tournament.updatedAt,
                syncDirty = false
            )
            parsed.copy(tournament = cloudTournament)
        }
    }

    private suspend fun <T> awaitTask(task: Task<T>): T = suspendCancellableCoroutine { cont ->
        task.addOnSuccessListener { result ->
            if (cont.isActive) cont.resume(result)
        }.addOnFailureListener { ex ->
            if (cont.isActive) cont.resumeWithException(ex)
        }
    }
}
