package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricketmanager.app.ui.theme.PitchEmeraldDark
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    isReady: Boolean,
    hasActiveUser: Boolean,
    onNavigateHome: () -> Unit,
    onNavigateAuth: () -> Unit
) {
    LaunchedEffect(isReady, hasActiveUser) {
        if (isReady) {
            delay(350)
            if (hasActiveUser) onNavigateHome() else onNavigateAuth()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PitchEmeraldDark),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "🏏", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Cricket Manager Ahmad",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = "ক্রিকেট টুর্নামেন্ট ও স্কোরিং সিস্টেম",
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFA7F3D0)
        )
        Spacer(Modifier.height(28.dp))
        CircularProgressIndicator(
            modifier = Modifier.size(32.dp),
            color = Color.White,
            strokeWidth = 3.dp
        )
    }
}
