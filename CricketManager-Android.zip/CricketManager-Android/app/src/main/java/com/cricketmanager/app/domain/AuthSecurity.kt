package com.cricketmanager.app.domain

import java.security.MessageDigest
import kotlin.random.Random

object AuthSecurity {
    private const val CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val SALT = "CricketManagerSalt2026"

    fun hashPassword(rawPassword: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest((rawPassword.trim() + SALT).toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(rawPassword: String, storedHash: String): Boolean {
        return hashPassword(rawPassword) == storedHash
    }

    fun generateCode(prefix: String = "CM", length: Int = 6): String {
        val randomPart = buildString {
            repeat(length) {
                append(CODE_CHARS[Random.nextInt(CODE_CHARS.length)])
            }
        }
        return if (prefix.isBlank()) randomPart else "$prefix$randomPart".take(8)
    }
}
