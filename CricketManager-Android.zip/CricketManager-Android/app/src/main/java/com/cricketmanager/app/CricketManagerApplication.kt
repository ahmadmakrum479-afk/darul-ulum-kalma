package com.cricketmanager.app

import android.app.Application
import com.cricketmanager.app.data.local.CricketDatabase
import com.cricketmanager.app.data.local.UserPreferences
import com.cricketmanager.app.data.repository.CricketRepository
import com.cricketmanager.app.sync.FirebaseSyncBridge
import com.cricketmanager.app.sync.TournamentSyncWorker

class CricketManagerApplication : Application() {
    val userPreferences: UserPreferences by lazy {
        UserPreferences(applicationContext)
    }

    val database: CricketDatabase by lazy {
        CricketDatabase.getInstance(applicationContext)
    }

    val firebaseSyncBridge: FirebaseSyncBridge by lazy {
        FirebaseSyncBridge(applicationContext)
    }

    val repository: CricketRepository by lazy {
        CricketRepository(
            dao = database.cricketDao(),
            preferences = userPreferences,
            firebaseSyncBridge = firebaseSyncBridge,
            appContext = applicationContext
        )
    }

    override fun onCreate() {
        super.onCreate()
        TournamentSyncWorker.schedulePeriodicSync(applicationContext)
    }
}
