package com.cricketmanager.app.data.local

import androidx.room.TypeConverter

class Converters {
    @TypeConverter fun fromPitchType(v: PitchType): String = v.name
    @TypeConverter fun toPitchType(v: String): PitchType =
        runCatching { PitchType.valueOf(v) }.getOrDefault(PitchType.FULL_PITCH)

    @TypeConverter fun fromScoringMode(v: ScoringMode): String = v.name
    @TypeConverter fun toScoringMode(v: String): ScoringMode =
        runCatching { ScoringMode.valueOf(v) }.getOrDefault(ScoringMode.BALL_BY_BALL)

    @TypeConverter fun fromTournamentFormat(v: TournamentFormat): String = v.name
    @TypeConverter fun toTournamentFormat(v: String): TournamentFormat =
        runCatching { TournamentFormat.valueOf(v) }.getOrDefault(TournamentFormat.LEAGUE)

    @TypeConverter fun fromMatchStage(v: MatchStage): String = v.name
    @TypeConverter fun toMatchStage(v: String): MatchStage =
        runCatching { MatchStage.valueOf(v) }.getOrDefault(MatchStage.LEAGUE)

    @TypeConverter fun fromMatchStatus(v: MatchStatus): String = v.name
    @TypeConverter fun toMatchStatus(v: String): MatchStatus =
        runCatching { MatchStatus.valueOf(v) }.getOrDefault(MatchStatus.UPCOMING)

    @TypeConverter fun fromPlayerRole(v: PlayerRole): String = v.name
    @TypeConverter fun toPlayerRole(v: String): PlayerRole =
        runCatching { PlayerRole.valueOf(v) }.getOrDefault(PlayerRole.ALL_ROUNDER)

    @TypeConverter fun fromWicketType(v: WicketType): String = v.name
    @TypeConverter fun toWicketType(v: String): WicketType =
        runCatching { WicketType.valueOf(v) }.getOrDefault(WicketType.NONE)

    @TypeConverter fun fromExtraType(v: ExtraType): String = v.name
    @TypeConverter fun toExtraType(v: String): ExtraType =
        runCatching { ExtraType.valueOf(v) }.getOrDefault(ExtraType.NONE)

    @TypeConverter fun fromUserRole(v: UserRole): String = v.name
    @TypeConverter fun toUserRole(v: String): UserRole =
        runCatching { UserRole.valueOf(v) }.getOrDefault(UserRole.VIEWER)

    @TypeConverter fun fromTieRule(v: TieRule): String = v.name
    @TypeConverter fun toTieRule(v: String): TieRule =
        runCatching { TieRule.valueOf(v) }.getOrDefault(TieRule.SHARE_POINTS)

    @TypeConverter fun fromPlayoffType(v: PlayoffType): String = v.name
    @TypeConverter fun toPlayoffType(v: String): PlayoffType =
        runCatching { PlayoffType.valueOf(v) }.getOrDefault(PlayoffType.SEMI_FINAL)
}
