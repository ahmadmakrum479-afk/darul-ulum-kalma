package com.cricketmanager.app.data.local

enum class PitchType(val labelEn: String, val labelBn: String) {
    SHORT_PITCH("Short Pitch", "শর্ট পিচ"),
    FULL_PITCH("Full Pitch", "ফুল পিচ")
}

enum class ScoringMode(val labelEn: String, val labelBn: String) {
    BALL_BY_BALL("Ball-by-Ball Live", "বল-বাই-বল লাইভ"),
    MANUAL("Manual Scorecard", "ম্যানুয়াল স্কোর")
}

enum class TournamentFormat(val labelEn: String, val labelBn: String) {
    LEAGUE("League", "লিগ"),
    ROUND_ROBIN("Round-Robin", "রাউন্ড-রবিন"),
    GROUP_KNOCKOUT("Group + Knockout", "গ্রুপ + নকআউট"),
    KNOCKOUT("Knockout", "নকআউট")
}

enum class MatchStage(val labelEn: String, val labelBn: String) {
    GROUP("Group Stage", "গ্রুপ পর্ব"),
    LEAGUE("League Match", "লিগ ম্যাচ"),
    KNOCKOUT("Knockout", "নকআউট"),
    QUALIFIER_1("Qualifier 1", "কোয়ালিফায়ার-১"),
    ELIMINATOR("Eliminator", "এলিমিনেটর"),
    QUALIFIER_2("Qualifier 2", "কোয়ালিফায়ার-২"),
    SEMI_FINAL("Semi-Final", "সেমিফাইনাল"),
    FINAL("Final", "ফাইনাল")
}

enum class MatchStatus(val labelEn: String, val labelBn: String) {
    UPCOMING("Upcoming", "আসন্ন"),
    LIVE("Live", "লাইভ"),
    COMPLETED("Completed", "সম্পন্ন"),
    ABANDONED("Abandoned", "পরিত্যক্ত"),
    WALKOVER("Walkover", "ওয়াকওভার")
}

enum class TieRule(val labelEn: String, val labelBn: String) {
    SUPER_OVER("Super Over", "সুপার ওভার"),
    SHARE_POINTS("Share Points", "পয়েন্ট ভাগ")
}

enum class PlayoffType(val labelEn: String, val labelBn: String) {
    NONE("None", "নেই"),
    FINAL_ONLY("Final Only", "শুধু ফাইনাল"),
    SEMI_FINAL("Semi-Finals & Final", "সেমি আর ফাইনাল"),
    QUALIFIER_ELIMINATOR("Qualifier 1, Eliminator, Q2 & Final", "কোয়ালিফায়ার-১, এলিমিনেটর, কোয়ালিফায়ার-২ ও ফাইনাল")
}

enum class TiebreakerCriterion(val labelEn: String, val labelBn: String) {
    POINTS("Points", "পয়েন্ট"),
    WINS("Wins", "জয়"),
    NRR("NRR", "NRR"),
    H2H("Head-to-Head", "মুখোমুখি ফল"),
    NAME("Team Name", "নাম")
}

enum class PlayerRole(val labelEn: String, val labelBn: String) {
    BATSMAN("Batsman", "ব্যাটসম্যান"),
    BOWLER("Bowler", "বোলার"),
    ALL_ROUNDER("All-Rounder", "অলরাউন্ডার"),
    WICKET_KEEPER("Wicket-Keeper", "উইকেটকিপার")
}

enum class WicketType(val labelEn: String, val labelBn: String) {
    NONE("Not Out", "নট আউট"),
    BOWLED("Bowled", "বোল্ড"),
    CAUGHT("Caught", "কট"),
    LBW("LBW", "এলবিডব্লিউ"),
    RUN_OUT("Run Out", "রান আউট"),
    STUMPED("Stumped", "স্টাম্পড"),
    HIT_WICKET("Hit Wicket", "হিট উইকেট")
}

enum class ExtraType(val labelEn: String, val labelBn: String) {
    NONE("Legal Ball", "সঠিক বল"),
    WIDE("Wide", "ওয়াইড"),
    NO_BALL("No Ball", "নো বল"),
    BYE("Bye", "বাই"),
    LEG_BYE("Leg Bye", "লেগ বাই")
}

enum class UserRole(val labelEn: String, val labelBn: String) {
    OWNER("Owner", "মালিক"),
    ADMIN("Admin", "অ্যাডমিন"),
    EDITOR("Editor / Scorer", "এডিটর / স্কোরার"),
    VIEWER("Viewer", "দর্শক")
}
