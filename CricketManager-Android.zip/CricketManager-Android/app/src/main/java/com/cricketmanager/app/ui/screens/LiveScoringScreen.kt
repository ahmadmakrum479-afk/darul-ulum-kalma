package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricketmanager.app.data.local.BallEventEntity
import com.cricketmanager.app.data.local.ExtraType
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.PlayerEntity
import com.cricketmanager.app.data.local.TieRule
import com.cricketmanager.app.data.local.WicketType
import com.cricketmanager.app.domain.CricketStatsEngine
import com.cricketmanager.app.ui.i18n.LocalAppStrings
import com.cricketmanager.app.ui.navigation.ScreenTopBar
import com.cricketmanager.app.ui.theme.BoundaryCrimson
import com.cricketmanager.app.ui.theme.GoldAccent
import com.cricketmanager.app.ui.theme.PitchEmerald
import com.cricketmanager.app.ui.theme.PitchEmeraldDark
import com.cricketmanager.app.viewmodel.CricketUiState
import com.cricketmanager.app.viewmodel.CricketViewModel
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LiveScoringScreen(
    matchId: Long,
    uiState: CricketUiState,
    viewModel: CricketViewModel,
    onBack: () -> Unit,
    onOpenScorecard: () -> Unit,
    onOpenManualScoring: () -> Unit
) {
    val strings = LocalAppStrings.current
    val match = uiState.allMatches.firstOrNull { it.id == matchId }

    if (match == null) {
        Scaffold(topBar = { ScreenTopBar(title = strings.liveScoring, onBack = onBack) }) { p ->
            Text("Match not found", modifier = Modifier.padding(p).padding(20.dp))
        }
        return
    }

    val tournament = uiState.tournaments.firstOrNull { it.id == match.tournamentId }
    val playersPerSideLimit = CricketStatsEngine.effectivePlayersPerSideForMatch(match, tournament)
    val maxOversPerBowler = when {
        match.maxOversPerBowlerSnapshot > 0 -> match.maxOversPerBowlerSnapshot
        tournament != null -> CricketStatsEngine.effectiveStageRules(tournament, match.stage).maxOversPerBowler
        else -> 4
    }.coerceAtLeast(1)
    val perms = uiState.permissionsFor(match.tournamentId)
    val tournamentPlayers = uiState.allPlayers.filter { it.tournamentId == match.tournamentId }
    val teamAFullSquad = tournamentPlayers.filter { it.teamId == match.teamAId }
    val teamBFullSquad = tournamentPlayers.filter { it.teamId == match.teamBId }
    val savedAPlayingIds = CricketStatsEngine.parsePlayingIds(match.teamAPlayingIds)
    val savedBPlayingIds = CricketStatsEngine.parsePlayingIds(match.teamBPlayingIds)

    val firstBatIsB = match.battingFirstTeamId == match.teamBId
    val battingTeamId = if (match.currentInnings == 1) {
        if (firstBatIsB) match.teamBId else match.teamAId
    } else {
        if (firstBatIsB) match.teamAId else match.teamBId
    }
    val bowlingTeamId = if (battingTeamId == match.teamAId) match.teamBId else match.teamAId
    val battingTeamIsA = battingTeamId == match.teamAId
    val fullBattingSquad = tournamentPlayers.filter { it.teamId == battingTeamId }.ifEmpty { tournamentPlayers }
    val fullBowlingSquad = tournamentPlayers.filter { it.teamId == bowlingTeamId }.ifEmpty { tournamentPlayers }
    val battingSelectedIds = if (battingTeamIsA) savedAPlayingIds else savedBPlayingIds
    val bowlingSelectedIds = if (battingTeamIsA) savedBPlayingIds else savedAPlayingIds
    val battingSquad = if (battingSelectedIds.isNotEmpty()) {
        fullBattingSquad.filter { it.id in battingSelectedIds }.ifEmpty { fullBattingSquad }
    } else {
        fullBattingSquad
    }
    val bowlingSquad = if (bowlingSelectedIds.isNotEmpty()) {
        fullBowlingSquad.filter { it.id in bowlingSelectedIds }.ifEmpty { fullBowlingSquad }
    } else {
        fullBowlingSquad
    }

    val striker = battingSquad.firstOrNull { it.id == match.activeStrikerId } ?: battingSquad.firstOrNull()
    val nonStriker = battingSquad.firstOrNull { it.id == match.activeNonStrikerId } ?: battingSquad.getOrNull(1)
    val bowler = bowlingSquad.firstOrNull { it.id == match.activeBowlerId } ?: bowlingSquad.firstOrNull()

    val inningsBalls = uiState.allBallEvents.filter { it.matchId == match.id && it.innings == match.currentInnings }
    val bowlerBalls = if (bowler != null) {
        inningsBalls.count { it.bowlerId == bowler.id && CricketStatsEngine.isLegalDelivery(it.extraType) }
    } else 0
    val bowlerOverQuotaReached = bowlerBalls >= maxOversPerBowler * 6
    val currentRuns = if (battingTeamIsA) match.teamARuns else match.teamBRuns
    val currentWickets = if (battingTeamIsA) match.teamAWickets else match.teamBWickets
    val currentLegalBalls = if (battingTeamIsA) match.teamABalls else match.teamBBalls
    val currentExtras = if (battingTeamIsA) match.teamAExtras else match.teamBExtras
    val crr = CricketStatsEngine.calculateCurrentRunRate(currentRuns, currentLegalBalls)

    var showPlayingXiDialog by remember { mutableStateOf(false) }
    var playingXiError by remember { mutableStateOf<String?>(null) }
    var showStrikerPicker by remember { mutableStateOf(false) }
    var showNonStrikerPicker by remember { mutableStateOf(false) }
    var showBowlerPicker by remember { mutableStateOf(false) }
    var showWicketDialog by remember { mutableStateOf(false) }
    var showExtraDialog by remember { mutableStateOf<ExtraType?>(null) }
    var showFinishDialog by remember { mutableStateOf(false) }
    var editingBall by remember { mutableStateOf<BallEventEntity?>(null) }

    Scaffold(
        topBar = {
            ScreenTopBar(
                title = "${match.teamAName} vs ${match.teamBName}",
                subtitle = "Innings ${match.currentInnings} · ${match.oversLimit} Overs · Max ${maxOversPerBowler} ov/bowler",
                onBack = onBack
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!perms.canScore) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(
                            text = strings.viewerReadOnlyNotice,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // Scoreboard Banner
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = PitchEmeraldDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val battingTeamName = if (battingTeamIsA) match.teamAName else match.teamBName
                        Text(
                            text = "$battingTeamName (Innings ${match.currentInnings})",
                            color = Color(0xFFD1FAE5),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "$currentRuns / $currentWickets",
                                fontSize = 38.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "Overs: ${CricketStatsEngine.formatOvers(currentLegalBalls)} / ${match.oversLimit}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = String.format(Locale.US, "CRR: %.2f · Extras: %d", crr, currentExtras),
                                color = Color(0xFFA7F3D0),
                                style = MaterialTheme.typography.bodySmall
                            )
                            if (match.currentInnings == 2) {
                                val target = (if (firstBatIsB) match.teamBRuns else match.teamARuns) + 1
                                val rrr = CricketStatsEngine.calculateRequiredRunRate(
                                    target, currentRuns, currentLegalBalls, match.oversLimit
                                )
                                Text(
                                    text = String.format(Locale.US, "Target: %d · RRR: %.2f", target, rrr),
                                    color = Color(0xFFFDE68A),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (bowlerOverQuotaReached && bowler != null) {
                            Text(
                                text = "⚠️ ${bowler.name} has completed max ${maxOversPerBowler} over(s). Change bowler.",
                                color = Color(0xFFFCA5A5),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (currentLegalBalls > 0 && currentLegalBalls % 6 == 0) {
                            Text(
                                text = "Over Complete — Tap Bowler below to change bowler if needed",
                                color = Color(0xFFFDE68A),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }

            // Active Batters & Bowler
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (perms.canScore) {
                            OutlinedButton(
                                onClick = {
                                    playingXiError = null
                                    showPlayingXiDialog = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "একাদশ বাছাই (${match.teamAName}: ${savedAPlayingIds.size}/$playersPerSideLimit · ${match.teamBName}: ${savedBPlayingIds.size}/$playersPerSideLimit)"
                                )
                            }
                        }
                        if (perms.canScore && match.currentInnings == 1 && match.teamABalls == 0 && match.teamBBalls == 0) {
                            Text("Batting First", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !firstBatIsB,
                                    onClick = { viewModel.updateBattingFirstTeam(match.id, match.teamAId) },
                                    label = { Text(match.teamAName) }
                                )
                                FilterChip(
                                    selected = firstBatIsB,
                                    onClick = { viewModel.updateBattingFirstTeam(match.id, match.teamBId) },
                                    label = { Text(match.teamBName) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { if (perms.canScore) showStrikerPicker = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("🏏* ${striker?.name ?: "Select Striker"}", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { if (perms.canScore) showNonStrikerPicker = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("🏏 ${nonStriker?.name ?: "Non-Striker"}", maxLines = 1)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { if (perms.canScore) showBowlerPicker = true },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("⚾ ${bowler?.name ?: "Select Bowler"}", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { if (perms.canScore) viewModel.swapStrike(match.id) },
                                modifier = Modifier.weight(0.75f)
                            ) {
                                Icon(Icons.Rounded.SwapHoriz, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text(strings.swapStrike, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Timeline of recent balls (tap any ball to edit)
            item {
                Card(shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Ball-by-Ball Timeline (Tap ball to edit)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (inningsBalls.isEmpty()) {
                            Text("No deliveries recorded in this innings yet.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(inningsBalls.reversed(), key = { it.id }) { ball ->
                                    val chipColor = when {
                                        ball.isWicket -> BoundaryCrimson
                                        ball.isBoundarySix -> GoldAccent
                                        ball.isBoundaryFour -> PitchEmerald
                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                    }
                                    val textColor = if (ball.isWicket || ball.isBoundaryFour || ball.isBoundarySix) {
                                        Color.White
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = chipColor,
                                        modifier = Modifier.clickable {
                                            if (perms.canScore) editingBall = ball
                                        }
                                    ) {
                                        Text(
                                            text = ball.summaryLabel,
                                            color = textColor,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Scoring Keypad
            if (perms.canScore && match.status != MatchStatus.COMPLETED && match.status != MatchStatus.ABANDONED) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Runs", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(0 to "Dot", 1 to "1", 2 to "2", 3 to "3").forEach { (runs, label) ->
                                    Button(
                                        onClick = {
                                            viewModel.recordBall(
                                                match.id, striker?.id ?: 0L, nonStriker?.id ?: 0L, bowler?.id ?: 0L,
                                                runsOffBat = runs, extraRuns = 0, extraType = ExtraType.NONE,
                                                isWicket = false, wicketType = WicketType.NONE, dismissedPlayerId = 0L
                                            )
                                        },
                                        modifier = Modifier.weight(1f).height(52.dp)
                                    ) { Text(label, fontWeight = FontWeight.Bold) }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = {
                                        viewModel.recordBall(
                                            match.id, striker?.id ?: 0L, nonStriker?.id ?: 0L, bowler?.id ?: 0L,
                                            runsOffBat = 4, extraRuns = 0, extraType = ExtraType.NONE,
                                            isWicket = false, wicketType = WicketType.NONE, dismissedPlayerId = 0L
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PitchEmerald),
                                    modifier = Modifier.weight(1f).height(52.dp)
                                ) { Text("FOUR (4)", fontWeight = FontWeight.Bold) }
                                Button(
                                    onClick = {
                                        viewModel.recordBall(
                                            match.id, striker?.id ?: 0L, nonStriker?.id ?: 0L, bowler?.id ?: 0L,
                                            runsOffBat = 6, extraRuns = 0, extraType = ExtraType.NONE,
                                            isWicket = false, wicketType = WicketType.NONE, dismissedPlayerId = 0L
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                    modifier = Modifier.weight(1f).height(52.dp)
                                ) { Text("SIX (6)", fontWeight = FontWeight.Bold) }
                                Button(
                                    onClick = { showWicketDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = BoundaryCrimson),
                                    modifier = Modifier.weight(1f).height(52.dp)
                                ) { Text("WICKET", fontWeight = FontWeight.Bold) }
                            }

                            Text("Extras", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf(
                                    ExtraType.WIDE to "Wide",
                                    ExtraType.NO_BALL to "No Ball",
                                    ExtraType.BYE to "Bye",
                                    ExtraType.LEG_BYE to "Leg Bye"
                                ).forEach { (extra, label) ->
                                    OutlinedButton(
                                        onClick = { showExtraDialog = extra },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(label, maxLines = 1) }
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { viewModel.undoLastBall(match.id) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.Undo, contentDescription = null)
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.undoBall)
                                }
                                if (match.currentInnings == 1) {
                                    Button(
                                        onClick = {
                                            viewModel.updateActivePlayers(match.id, 2, 0L, 0L, 0L, MatchStatus.LIVE)
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(strings.switchInnings) }
                                } else {
                                    Button(
                                        onClick = { showFinishDialog = true },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(strings.finalizeMatch) }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onOpenScorecard, modifier = Modifier.weight(1f)) {
                        Text(strings.scorecard)
                    }
                    if (perms.canScore) {
                        OutlinedButton(onClick = onOpenManualScoring, modifier = Modifier.weight(1f)) {
                            Text(strings.manualScoring)
                        }
                        if (match.currentInnings == 1 && match.status != MatchStatus.COMPLETED) {
                            OutlinedButton(onClick = { showFinishDialog = true }, modifier = Modifier.weight(1f)) {
                                Text(strings.finalizeMatch)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showStrikerPicker) {
        PlayerSelectDialog(
            title = "Select Striker",
            players = battingSquad,
            onSelect = { p ->
                viewModel.updateActivePlayers(
                    match.id, match.currentInnings, p.id, nonStriker?.id ?: 0L, bowler?.id ?: 0L
                )
                showStrikerPicker = false
            },
            onDismiss = { showStrikerPicker = false }
        )
    }

    if (showNonStrikerPicker) {
        PlayerSelectDialog(
            title = "Select Non-Striker",
            players = battingSquad,
            onSelect = { p ->
                viewModel.updateActivePlayers(
                    match.id, match.currentInnings, striker?.id ?: 0L, p.id, bowler?.id ?: 0L
                )
                showNonStrikerPicker = false
            },
            onDismiss = { showNonStrikerPicker = false }
        )
    }

    if (showBowlerPicker) {
        PlayerSelectDialog(
            title = "Select Bowler",
            players = bowlingSquad,
            onSelect = { p ->
                viewModel.updateActivePlayers(
                    match.id, match.currentInnings, striker?.id ?: 0L, nonStriker?.id ?: 0L, p.id
                )
                showBowlerPicker = false
            },
            onDismiss = { showBowlerPicker = false }
        )
    }

    if (showWicketDialog) {
        var wicketType by remember { mutableStateOf(WicketType.BOWLED) }
        var runsOnWicket by remember { mutableIntStateOf(0) }
        var dismissedId by remember { mutableStateOf(striker?.id ?: 0L) }

        AlertDialog(
            onDismissRequest = { showWicketDialog = false },
            title = { Text("Record Wicket") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Dismissal Type", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        WicketType.entries.filter { it != WicketType.NONE }.forEach { wt ->
                            FilterChip(selected = wicketType == wt, onClick = { wicketType = wt }, label = { Text(wt.labelEn) })
                        }
                    }
                    Text("Runs completed before wicket", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 1, 2).forEach { r ->
                            FilterChip(selected = runsOnWicket == r, onClick = { runsOnWicket = r }, label = { Text("$r") })
                        }
                    }
                    Text("Batter Out", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (striker != null) {
                            FilterChip(selected = dismissedId == striker.id, onClick = { dismissedId = striker.id }, label = { Text(striker.name) })
                        }
                        if (nonStriker != null) {
                            FilterChip(selected = dismissedId == nonStriker.id, onClick = { dismissedId = nonStriker.id }, label = { Text(nonStriker.name) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.recordBall(
                        match.id, striker?.id ?: 0L, nonStriker?.id ?: 0L, bowler?.id ?: 0L,
                        runsOffBat = runsOnWicket, extraRuns = 0, extraType = ExtraType.NONE,
                        isWicket = true, wicketType = wicketType, dismissedPlayerId = dismissedId
                    )
                    showWicketDialog = false
                }) { Text("Confirm Wicket") }
            },
            dismissButton = { TextButton(onClick = { showWicketDialog = false }) { Text(strings.cancel) } }
        )
    }

    showExtraDialog?.let { extraType ->
        var extraRuns by remember { mutableIntStateOf(1) }
        var batRuns by remember { mutableIntStateOf(0) }
        AlertDialog(
            onDismissRequest = { showExtraDialog = null },
            title = { Text("Record ${extraType.labelEn}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Total Extra Runs", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 2, 3, 4, 5).forEach { r ->
                            FilterChip(selected = extraRuns == r, onClick = { extraRuns = r }, label = { Text("$r") })
                        }
                    }
                    if (extraType == ExtraType.NO_BALL) {
                        Text("Runs off Bat (if hit)", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 1, 2, 4, 6).forEach { r ->
                                FilterChip(selected = batRuns == r, onClick = { batRuns = r }, label = { Text("$r") })
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.recordBall(
                        match.id, striker?.id ?: 0L, nonStriker?.id ?: 0L, bowler?.id ?: 0L,
                        runsOffBat = batRuns, extraRuns = extraRuns, extraType = extraType,
                        isWicket = false, wicketType = WicketType.NONE, dismissedPlayerId = 0L
                    )
                    showExtraDialog = null
                }) { Text("Save Extra") }
            },
            dismissButton = { TextButton(onClick = { showExtraDialog = null }) { Text(strings.cancel) } }
        )
    }

    editingBall?.let { ball ->
        var runs by remember { mutableIntStateOf(ball.runsOffBat) }
        var extraRuns by remember { mutableIntStateOf(ball.extraRuns) }
        var extraType by remember { mutableStateOf(ball.extraType) }
        var isWicket by remember { mutableStateOf(ball.isWicket) }
        var wicketType by remember { mutableStateOf(ball.wicketType) }

        AlertDialog(
            onDismissRequest = { editingBall = null },
            title = { Text("Edit Ball #${ball.sequenceNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Runs Off Bat", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 1, 2, 3, 4, 6).forEach { r ->
                            FilterChip(selected = runs == r, onClick = { runs = r }, label = { Text("$r") })
                        }
                    }
                    Text("Extra Type", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExtraType.entries.forEach { et ->
                            FilterChip(
                                selected = extraType == et,
                                onClick = {
                                    extraType = et
                                    extraRuns = if (et == ExtraType.NONE) 0 else extraRuns.coerceAtLeast(1)
                                },
                                label = { Text(et.labelEn) }
                            )
                        }
                    }
                    FilterChip(
                        selected = isWicket,
                        onClick = {
                            isWicket = !isWicket
                            if (isWicket && wicketType == WicketType.NONE) wicketType = WicketType.CAUGHT
                        },
                        label = { Text(if (isWicket) "Wicket: YES" else "Wicket: NO") }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.editBallEvent(ball.id, runs, extraRuns, extraType, isWicket, wicketType)
                    editingBall = null
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { editingBall = null }) { Text(strings.cancel) } }
        )
    }

    if (showFinishDialog) {
        val matchPlayers = tournamentPlayers.filter { it.teamId == match.teamAId || it.teamId == match.teamBId }
        val matchBalls = uiState.allBallEvents.filter { it.matchId == match.id }
        val provisionalWinnerId = when {
            match.teamARuns > match.teamBRuns -> match.teamAId
            match.teamBRuns > match.teamARuns -> match.teamBId
            else -> 0L
        }
        val rankedPerformers = CricketStatsEngine.calculateBallEventsImpactMap(
            matchPlayers, matchBalls, provisionalWinnerId, tournament
        )
        val autoBest = rankedPerformers.firstOrNull()
        var autoSelectPom by remember(match.id) { mutableStateOf(true) }
        var manualPom by remember(match.id) { mutableStateOf(autoBest?.first ?: matchPlayers.firstOrNull()) }
        var abandoned by remember { mutableStateOf(false) }
        var superOverWinnerId by remember(match.id) { mutableStateOf(match.winnerTeamId) }
        val isTiedScore = match.teamARuns == match.teamBRuns

        val effectivePom = if (autoSelectPom) (autoBest?.first ?: manualPom) else manualPom

        AlertDialog(
            onDismissRequest = { showFinishDialog = false },
            title = { Text(strings.finalizeMatch) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = abandoned,
                        onClick = { abandoned = !abandoned },
                        label = { Text(if (abandoned) "Mark Abandoned (Rain / Tie)" else "Normal Completed Match") }
                    )
                    if (!abandoned && isTiedScore && tournament?.tieRule == TieRule.SUPER_OVER) {
                        Text("সুপার ওভারে বিজয়ী বাছুন", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = superOverWinnerId == 0L,
                                onClick = { superOverWinnerId = 0L },
                                label = { Text("সুপার ওভার বাকি") }
                            )
                            FilterChip(
                                selected = superOverWinnerId == match.teamAId,
                                onClick = { superOverWinnerId = match.teamAId },
                                label = { Text(match.teamAName) }
                            )
                            FilterChip(
                                selected = superOverWinnerId == match.teamBId,
                                onClick = { superOverWinnerId = match.teamBId },
                                label = { Text(match.teamBName) }
                            )
                        }
                    }
                    if (!abandoned && matchPlayers.isNotEmpty()) {
                        Text("Man of the Match (Auto Impact Score)", style = MaterialTheme.typography.labelMedium)
                        if (autoBest != null) {
                            FilterChip(
                                selected = autoSelectPom,
                                onClick = { autoSelectPom = true },
                                label = { Text("⚡ Auto: ${autoBest.first.name} (${String.format(Locale.US, "%.2f", autoBest.second.totalScore)})") }
                            )
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rankedPerformers.take(10).forEach { (p, bd) ->
                                FilterChip(
                                    selected = !autoSelectPom && manualPom?.id == p.id,
                                    onClick = {
                                        autoSelectPom = false
                                        manualPom = p
                                    },
                                    label = { Text("${p.name} (${String.format(Locale.US, "%.2f", bd.totalScore)})") }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val chosenId = if (autoSelectPom) 0L else (effectivePom?.id ?: 0L)
                    val chosenName = if (autoSelectPom) "" else (effectivePom?.name ?: "")
                    viewModel.finalizeMatch(
                        matchId = match.id,
                        pomId = chosenId,
                        pomName = chosenName,
                        isAbandoned = abandoned,
                        superOverWinnerTeamId = if (!abandoned && isTiedScore) superOverWinnerId else 0L,
                        onError = { playingXiError = it },
                        onSuccess = {
                            showFinishDialog = false
                            onOpenScorecard()
                        }
                    )
                }) { Text(strings.finalizeMatch) }
            },
            dismissButton = { TextButton(onClick = { showFinishDialog = false }) { Text(strings.cancel) } }
        )
    }

    if (showPlayingXiDialog) {
        var draftAIds by remember(match.id, showPlayingXiDialog) {
            mutableStateOf(
                if (savedAPlayingIds.isNotEmpty()) savedAPlayingIds
                else teamAFullSquad.take(playersPerSideLimit).map { it.id }
            )
        }
        var draftBIds by remember(match.id, showPlayingXiDialog) {
            mutableStateOf(
                if (savedBPlayingIds.isNotEmpty()) savedBPlayingIds
                else teamBFullSquad.take(playersPerSideLimit).map { it.id }
            )
        }
        val errA = CricketStatsEngine.validatePlayingSelection(draftAIds, playersPerSideLimit)
        val errB = CricketStatsEngine.validatePlayingSelection(draftBIds, playersPerSideLimit)
        val activeErr = errA?.let { "${match.teamAName}: $it" }
            ?: errB?.let { "${match.teamBName}: $it" }
            ?: playingXiError

        AlertDialog(
            onDismissRequest = { showPlayingXiDialog = false },
            title = { Text("একাদশ বাছুন (সর্বোচ্চ $playersPerSideLimit জন)") },
            text = {
                LazyColumn(modifier = Modifier.height(340.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (activeErr != null) {
                        item {
                            Text(
                                text = activeErr,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    item {
                        Text(
                            "${match.teamAName} (${draftAIds.size} / $playersPerSideLimit)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    item {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            teamAFullSquad.forEach { p ->
                                val selected = p.id in draftAIds
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        playingXiError = null
                                        draftAIds = if (selected) draftAIds - p.id else draftAIds + p.id
                                    },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                    }
                    item {
                        Text(
                            "${match.teamBName} (${draftBIds.size} / $playersPerSideLimit)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    item {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            teamBFullSquad.forEach { p ->
                                val selected = p.id in draftBIds
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        playingXiError = null
                                        draftBIds = if (selected) draftBIds - p.id else draftBIds + p.id
                                    },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val vA = CricketStatsEngine.validatePlayingSelection(draftAIds, playersPerSideLimit)
                    if (vA != null) {
                        playingXiError = "${match.teamAName}: $vA"
                        return@Button
                    }
                    val vB = CricketStatsEngine.validatePlayingSelection(draftBIds, playersPerSideLimit)
                    if (vB != null) {
                        playingXiError = "${match.teamBName}: $vB"
                        return@Button
                    }
                    viewModel.saveMatchPlayingSquad(
                        matchId = match.id,
                        teamAIds = draftAIds,
                        teamBIds = draftBIds,
                        onError = { playingXiError = it },
                        onSaved = { showPlayingXiDialog = false }
                    )
                }) { Text(strings.save) }
            },
            dismissButton = { TextButton(onClick = { showPlayingXiDialog = false }) { Text(strings.cancel) } }
        )
    }
}

@Composable
private fun PlayerSelectDialog(
    title: String,
    players: List<PlayerEntity>,
    onSelect: (PlayerEntity) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(modifier = Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(players, key = { it.id }) { p ->
                    OutlinedButton(
                        onClick = { onSelect(p) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("#${p.jerseyNumber} ${p.name} (${p.role.labelEn})")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
